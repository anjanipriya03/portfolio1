import React from "react";
import "./index.css";
function App() {
  return (
    <div>
      Hi Chinnu
    </div>
  );
}

export default App;
